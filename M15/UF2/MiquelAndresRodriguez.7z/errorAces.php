<?php
?>

<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<title>Error acces</title>
</head>
<body>
    <p> L’usuari i/o password eren incorrectes</p>
	<form method="GET" action="Formulari.html">               

		<input type="submit" name="enviar" value="Retornar Al formulari" />

	</form>

</body>
</html>