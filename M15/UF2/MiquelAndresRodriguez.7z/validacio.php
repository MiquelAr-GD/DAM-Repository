<?php

define("USUARI", "Alfredo");
define("PASSWORD", "123");
define("USUARI2", "Miquel");
define("PASSWORD2", "1234");


if (($_POST["usuari"] == USUARI && $_POST["contrasenya"] == PASSWORD) OR ( $_POST["usuari"] == USUARI2 && $_POST["contrasenya"] == PASSWORD2)) {
    session_start();
    $_SESSION["usuari"] = $_POST["usuari"];
    $_SESSION["contrasenya"] = $_POST["contrasenya"];
    $_SESSION["JP"] = $_POST["JP"];
    $_SESSION["Posicio"] = $_POST["posicio"];

    session_cache_expire(45);

    header("Location: informacio.php");
} else {
    header("location:errorAces.php");
}
?>