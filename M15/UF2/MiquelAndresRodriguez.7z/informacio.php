
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="content-type" content="text/html;charset=utf-8" />
        <title>Inici</title>
    </head>
    <body>
        <?php
        session_start();
        echo "<p>Hola " . $_SESSION["usuari"] . "! La teva contrasenya és " . $_SESSION["contrasenya"] . ", el teu joc preferit és " . $_SESSION["JP"] . " i la posició en què sols quedar quan jugues és la " . $_SESSION["Posicio"] . ".</p>";
        echo"<p>";
        print_r($_SESSION);
        echo"</p>";
        ?>
        <form method="POST" action="Formulari.html">
            <input type="submit" name="enviar" value="Tornar" />
        </form>
        <form method="POST" action="esborrat.php">
            <input type="submit" name="enviar" value="Esborrar" />
        </form>

    </body>
</html>