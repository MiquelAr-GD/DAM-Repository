<?php
	session_start();
	session_destroy();
	$_SESSION=array();
?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<title>Tancar Sessió</title>
</head>
    <body>
        <h3>Sessió esborrada</h3>
        <form method="POST" action="Formulari.html">
            <input type="submit" name="enviar" value="Tornar" />
        </form>
    </body>
</html>